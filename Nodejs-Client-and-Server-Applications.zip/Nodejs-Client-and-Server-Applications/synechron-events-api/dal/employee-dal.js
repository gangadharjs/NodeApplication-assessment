const monojs = require('mongojs');
const db = monojs('synechron-events-db', ['employees']);

class EmployeeDal {
    constructor() {

    }
    getAllEemployees() {
        return new Promise((resolve, reject) => {
            db.employees.find((err, docs) => {
              if(err) {
                  reject(err);
              }  
              resolve(docs);
            })
        })
    }
    
    getEmployeeDetails(employeeId) {
        return new Promise((resolve, reject) => {
            db.employees.findOne({"employeeId": Number.parseInt(employeeId)}, (err, doc) => {
                if(err) {
                    reject(err);
                }  
                resolve(doc);
              })
        })
    }

    registerNewEmployee(employee) {
        let newEmployee ={
            ...employee,
            employeeId: Number.parseInt(employee.employeeId),
            phone: Number.parseInt(employee.phone),
            avatar:"images/noimage.png"
        };
        return new Promise((resolve, reject) => {
            db.employees.insert(newEmployee, (err, doc) => {
                if(err) {
                    reject(err);
                }
                resolve(doc);
            })
        });
    }

}

module.exports = new EmployeeDal();