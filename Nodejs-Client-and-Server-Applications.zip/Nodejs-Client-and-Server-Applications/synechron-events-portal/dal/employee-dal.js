class EmployeeDal {
    constructor() {

    }
    getAllEmployees() {
        return [
            {
                employeeId: 2378,
                employeeName: "Pravinkumar R. D.",
                address: "Suncity, A8/404",
                city: "Pune",
                phone: "+91 23873278",
                email: "dabade.pravinkumar@gmail.com",
                skillSets: "Microsoft, JavaScript, Databases",
                projectName: "Training on PoCs",
                avatar: "images/noimage.png"
            },
            {
                employeeId: 2379,
                employeeName: "Manish Kaushik",
                address: "Moon, A8/404",
                city: "Pune",
                phone: "+91 89898989",
                email: "manishk@gmail.com",
                skillSets: "Databases",
                projectName: "DBA",
                avatar: "images/noimage.png"
            },
            {
                employeeId: 2380,
                employeeName: "Anjala Johns",
                address: "River City, A8/404",
                city: "Mumbai",
                phone: "+91 5645344",
                email: "anjalaj@gmail.com",
                skillSets: "Microsoft, JavaScript, Databases",
                projectName: "Training on PoCs",
                avatar: "images/noimage.png"
            }
        ]
    }
    getEmployeeDetails(employeeId) {
        return this.getAllEmployees().filter(
            employee => {
                if(employee.employeeId == employeeId) {
                    return employee;
                }
            }
        )[0];
    }
}

module.exports = new EmployeeDal();