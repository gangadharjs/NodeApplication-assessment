const monojs = require('mongojs');
const db = monojs('synechron-events-db', ['events']);

class EventDal {
    constructor() {

    }
    getAllEvents() {
        return new Promise((resolve, reject) => {
            db.events.find((err, docs) => {
              if(err) {
                  reject(err);
              }  
              resolve(docs);
            })
        })
    }
    
    getEventDetails(eventId) {
        return new Promise((resolve, reject) => {
            db.events.findOne({"eventId": Number.parseInt(eventId)}, (err, doc) => {
                if(err) {
                    reject(err);
                }  
                resolve(doc);
              })
        })
    }

    registerNewEvent(event) {
        let newEvent ={
            ...event,
            eventId: Number.parseInt(event.eventId),
            fees: Number.parseInt(event.fees),
            seatsFilled: Number.parseInt(event.seatsFilled),
            logo:"images/noimage.png"
        };
        return new Promise((resolve, reject) => {
            db.events.insert(newEvent, (err, doc) => {
                if(err) {
                    reject(err);
                }
                resolve(doc);
            })
        });
    }

}

module.exports = new EventDal();