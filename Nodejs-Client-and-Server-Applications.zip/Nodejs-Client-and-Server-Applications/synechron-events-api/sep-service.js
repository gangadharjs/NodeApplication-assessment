const express = require('express');
const bodyParser = require('body-parser');  //converting
const cors = require('cors');   //cross origin
const morgan = require('morgan');   //logger
const eventRoutes = require('./service-routes/event-routes'); //routes
const employeeRoutes = require('./service-routes/employee-routes'); //routes
const securityRoutes = require('./service-routes/security-routes'); //routes


const app = express();

app.use(cors({}));  //Middle wares 
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));
app.use(morgan("dev"));

app.use('/api/events', eventRoutes);
app.use('/api/employees', employeeRoutes);
app.use('/api/auth', securityRoutes);

app.listen(9090, () => console.log('synechron is running on port 9090'));
